package com.mindtree.test;

import static org.junit.Assert.*;

import com.mindtree.dao.CustomerDao;
import com.mindtree.entity.Customer;

public class Test {

	@org.junit.Test
	public void test() throws ClassNotFoundException {
		CustomerDao obj = new CustomerDao();
		Customer m= new Customer(12340,"Ranjan",5000,"BVCTR7766D");
		int res= obj.addCustomer(m);
		assertEquals(1, res);
	}

}
