package com.mindtree.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ErrorMessage {
	
	String reason;
	
	
	public ErrorMessage() {
		
	}


	public ErrorMessage(String errorMessage) {
		this.reason = errorMessage;
	}


	public String getErrorMessage() {
		return reason;
	}


	public void setErrorMessage(String errorMessage) {
		this.reason = errorMessage;
	}

}
