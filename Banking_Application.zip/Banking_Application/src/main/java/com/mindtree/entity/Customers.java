package com.mindtree.entity;

import java.util.ArrayList;


public class Customers {
public ArrayList<Customer> customers;

public ArrayList<Customer> getCustomers() {
	return customers;
}

public void setCustomers(ArrayList<Customer> customers) {
	this.customers = customers;
}
 public Customers() {
	// TODO Auto-generated constructor stub
	customers= new ArrayList<Customer>();
}
	


public void addCustomer(Customer customer1) {
	customers.add(customer1);
}

	


}
