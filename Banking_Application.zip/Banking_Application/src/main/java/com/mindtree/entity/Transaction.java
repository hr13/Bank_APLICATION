package com.mindtree.entity;

public class Transaction {
	private int trans_id;
	private int fromAcc;
	private int toAcc;
	private String tranc;
	private int current_bal;
	private String Pan;
	public Transaction(int trans_id, int fromAcc, int toAcc, String tranc, int current_bal, String pan) {
		super();
		this.trans_id = trans_id;
		this.fromAcc = fromAcc;
		this.toAcc = toAcc;
		this.tranc = tranc;
		this.current_bal = current_bal;
		Pan = pan;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTrans_id() {
		return trans_id;
	}
	public void setTrans_id(int trans_id) {
		this.trans_id = trans_id;
	}
	public int getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(int fromAcc) {
		this.fromAcc = fromAcc;
	}
	public int getToAcc() {
		return toAcc;
	}
	public void setToAcc(int toAcc) {
		this.toAcc = toAcc;
	}
	public String getTranc() {
		return tranc;
	}
	public void setTranc(String tranc) {
		this.tranc = tranc;
	}
	public int getCurrent_bal() {
		return current_bal;
	}
	public void setCurrent_bal(int current_bal) {
		this.current_bal = current_bal;
	}
	public String getPan() {
		return Pan;
	}
	public void setPan(String pan) {
		Pan = pan;
	}
	public String toString() {
		return "Transaction [trans_id=" + trans_id + ", fromAcc=" + fromAcc + "toAcc="+toAcc+"to tranc=" + tranc + ", current_bal="
				+ current_bal + ", Pan=" + Pan + "]";
	}
	
}
