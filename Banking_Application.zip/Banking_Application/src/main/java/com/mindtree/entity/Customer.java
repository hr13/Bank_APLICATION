package com.mindtree.entity;

public class Customer {
	private int accno;
	private String name;
	private int balance;
	private String pan;
	public Customer(int accno, String name, int balance, String pan) {
		super();
		this.accno = accno;
		this.name = name;
		this.balance = balance;
		this.pan = pan;
	}
	public Customer() {
		super();
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	@Override
	public String toString() {
		return "Customer [accno=" + accno + ", name=" + name + ", balance=" + balance + ", pan=" + pan + "]";
	}
	
}
