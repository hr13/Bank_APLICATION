package com.mindtree.entity;

public class AffectedRows {

int affectedRows;
	
	public AffectedRows() {
		affectedRows=0;
	}
	public AffectedRows(int affectedRows) {
		this.affectedRows=affectedRows;
	}

	public int getAffectedRows() {
		return affectedRows;
	}

	public void setAffectedRows(int affectedRows) {
		this.affectedRows = affectedRows;
	}
}
