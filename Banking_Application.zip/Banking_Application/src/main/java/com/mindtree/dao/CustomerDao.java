package com.mindtree.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;

import com.mindtree.Utility.Utility;
import com.mindtree.entity.Customer;
import com.mindtree.entity.Customers;
import com.mindtree.entity.Transaction;
import com.mysql.jdbc.PreparedStatement;







public class CustomerDao {
	public int addCustomer(Customer customer) throws ClassNotFoundException {
		Connection con = null;
		int result = 0;
		try {
			con = new Utility().getConnection();	

//			
			Statement statement = con.createStatement();
			//System.out.println(customer.getName());
			
			String sql = "insert into customer values('"+customer.getAccno()+"','"+customer.getName()+"','"+customer.getBalance()+"','"+customer.getPan()+"');";
			result = statement.executeUpdate(sql);
			con.close();
		} catch (SQLException e) {
			System.out.println("insert error");
			e.printStackTrace();
			
		}
		return result;
	}

	public ArrayList<Customer> getAllCustomers() throws ClassNotFoundException {
		Customers emp = new Customers();
		ArrayList<Customer> customerList=new ArrayList<Customer>();

		Connection con;
		try {
			con = new Utility().getConnection();
			Statement statement = con.createStatement();
			String sql = "SELECT * FROM customer";
			ResultSet resultSet = statement.executeQuery(sql);
			while(resultSet.next()) {
				Customer customer = new Customer();
				customer.setAccno(resultSet.getInt("accno"));
				customer.setName(resultSet.getString("name"));
				customer.setBalance(resultSet.getInt("balance"));
				customer.setPan(resultSet.getString("pan"));
				customerList.add(customer);
			}
			System.out.println(customerList.size());
			
			con.close();
//			emp.setCustomers(customerList);
			
		} catch (SQLException e) {
			
		}
		return customerList;
		
	}
	public Customer getCustomerById(int id) throws ClassNotFoundException {
		Connection con;
		Customer customer = null;
		try {
			con = new Utility().getConnection();
			Statement statement = con.createStatement();
			String sql = "select * from customer where accno = "+id+";";
			ResultSet resultSet = statement.executeQuery(sql);
			if(resultSet.next()) {
				customer = new Customer();
				customer.setName(resultSet.getString("name"));
				customer.setBalance(resultSet.getInt("balance"));
				customer.setPan(resultSet.getString("pan"));
			}
			con.close();
		} catch (SQLException e) {
		}
		return customer;
	}

	public int deposit(Customer customer) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		
		Connection con = null;
		int result = 0;
		try {
			con = new Utility().getConnection();	
			int bal=customer.getBalance();
			int acc=customer.getAccno();
			System.out.println(acc);
			int old_bal=0;
			System.out.println(bal);
			Statement statement1 = con.createStatement();
			String sql1= "select balance from customer where accno="+customer.getAccno()+";";
			ResultSet rst1= statement1.executeQuery(sql1);
			if(rst1.next()) {
				old_bal =rst1.getInt("balance");
			}
			System.out.println(old_bal);
			int new_bal=0;
			new_bal=bal+old_bal;
			
			Statement statement = con.createStatement();
			
			
			
			//ResultSet res = statement.executeQuery("select * from customer where accno = "+customer.getAccno()+";");
			String sql = "update customer set balance ="+new_bal+" where accno="+acc+";";
			result = statement.executeUpdate(sql);
			con.close();
		} catch (SQLException e) {
			System.out.println("insert error");
			e.printStackTrace();
			
		}
		return result;
	}

public int withdrawal(Customer customer) throws Exception {
	// TODO Auto-generated method stub
	
	Connection con = null;
	int result = 0;
	try {
		con = new Utility().getConnection();	
		int bal=customer.getBalance();
		int acc=customer.getAccno();
		System.out.println(acc);
		int old_bal=0;
		System.out.println(bal);
		Statement statement1 = con.createStatement();
		String sql1= "select balance from customer where accno="+customer.getAccno()+";";
		ResultSet rst1= statement1.executeQuery(sql1);
		if(rst1.next()) {
			old_bal =rst1.getInt("balance");
		}
		System.out.println(old_bal);
		int new_bal=0;
		new_bal=old_bal-bal;
		if(new_bal<0) {
			throw new Exception();
		}
		
		Statement statement = con.createStatement();
		
		
		
		//ResultSet res = statement.executeQuery("select * from customer where accno = "+customer.getAccno()+";");
		String sql = "update customer set balance ="+new_bal+" where accno="+acc+";";
		result = statement.executeUpdate(sql);
		con.close();
	} catch (SQLException e) {
		System.out.println("insert error");
		e.printStackTrace();
		
	}
	finally {
		if(result ==0) {
			return result;
		}
	}
	return result;
}

public int transfer(Transaction customer) throws Exception {
	Connection con = null;
	int result1 = 0;
	int result2=0;
	int res=0;
	try {
		con = new Utility().getConnection();	
		int bal=customer.getCurrent_bal();
		int acc=customer.getFromAcc();
		System.out.println(acc);
		int old_bal=0;
		System.out.println(bal);
		Statement statement1 = con.createStatement();
		String sql1= "select balance from customer where accno="+customer.getFromAcc()+";";
		ResultSet rst1= statement1.executeQuery(sql1);
		if(rst1.next()) {
			old_bal =rst1.getInt("balance");
		}
		System.out.println(old_bal);
		int new_bal=0;
		new_bal=old_bal-bal;
		System.out.println(new_bal);
		if(new_bal<0) {
			throw new Exception();
		}
		
		Statement statement = con.createStatement();
		
		
		
		//ResultSet res = statement.executeQuery("select * from customer where accno = "+customer.getAccno()+";");
		String sql = "update customer set balance ="+new_bal+" where accno="+acc+";";
		result1 = statement.executeUpdate(sql);
		//int bal2=customer.getB();
		int acc2=customer.getToAcc();
		System.out.println(acc2);
		int old_bal2=0;
		//System.out.println(bal);
		Statement statement2 = con.createStatement();
		String sql2= "select balance from customer where accno="+acc2+";";
		ResultSet rst2= statement2.executeQuery(sql2);
		if(rst2.next()) {
			old_bal2 =rst2.getInt("balance");
		}
		System.out.println(old_bal2);
		int new_bal2=0;
		new_bal2=old_bal2+bal;
		
		Statement statement3 = con.createStatement();
		
		
		
		//ResultSet res = statement.executeQuery("select * from customer where accno = "+customer.getAccno()+";");
		String sql3 = "update customer set balance ="+new_bal2+" where accno="+acc2+";";
		result2 = statement3.executeUpdate(sql3);
		
		if(result1==1 && result2==1) {
			res=1;
		}
		con.close();
	} catch (SQLException e) {
		System.out.println("insert error");
		e.printStackTrace();
		
	}
	
	finally {
		if(result1==0 ||result2==0)
		return 0;
		else
			return res;
	}
}

}
