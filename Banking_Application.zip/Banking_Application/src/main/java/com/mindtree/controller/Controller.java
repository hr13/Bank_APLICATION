package com.mindtree.controller;

import java.util.ArrayList;

import org.springframework.http.MediaType;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mindtree.dao.CustomerDao;
import com.mindtree.entity.AffectedRows;
import com.mindtree.entity.Customer;
import com.mindtree.entity.Customers;
import com.mindtree.entity.ErrorMessage;
import com.mindtree.entity.Transaction;


@org.springframework.stereotype.Controller
public class Controller {
	@ResponseBody
	@PostMapping(value="/addCustomer",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public AffectedRows addCustomer(@RequestBody Customer customer) throws ClassNotFoundException {
		System.out.println("came");
		int result = new CustomerDao().addCustomer(customer);
		return new AffectedRows(result);
	}
	@ResponseBody
	@GetMapping(value="/getAllCustomer",produces= {MediaType.APPLICATION_JSON_VALUE})
	public  ArrayList<Customer> getCustomers() throws ClassNotFoundException {
		System.out.println("here");
		 ArrayList<Customer> cs=  new ArrayList<Customer>();
		 
		 CustomerDao cd= new CustomerDao();
		 
		 cs=cd.getAllCustomers();
		//cs  = new CustomerDao().getAllCustomers();
		//System.out.println(emp.customers.size());
		return cs;
	}
	@ResponseBody
	@PostMapping(value="/deposit",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public AffectedRows deposit(@RequestBody Customer customer) throws ClassNotFoundException {
		System.out.println("came");
		int result = new CustomerDao().deposit(customer);
		return new AffectedRows(result);
	}
	@ResponseBody
	@PostMapping(value="/withdrawl",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public AffectedRows withdrawl(@RequestBody Customer customer) throws Exception {
		System.out.println("came");
		int result = new CustomerDao().withdrawal(customer);
		return new AffectedRows(result);
	}
	@ResponseBody
	@PostMapping(value="/transfer",consumes= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public AffectedRows transfer(@RequestBody Transaction customer) throws Exception {
		System.out.println("came");
		int result = new CustomerDao().transfer(customer);
		return new AffectedRows(result);
	}
	
	
	
	@ResponseBody
	@GetMapping(value="/getCustomerById/{id}",produces={MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public Object getCustomer(@PathVariable int id) throws ClassNotFoundException {
		System.out.println("came");
		Customer customer = new CustomerDao().getCustomerById(id);
		
		if(null!=customer) {
			return customer;
		}
		else {
			return new ErrorMessage("Employee id "+id+" is not present");
		}
	}
	
	@RequestMapping("/bank")
	public String page() {
		return "Bank.html";
	}
	@RequestMapping(value = "/redirect", method = RequestMethod.GET)
	   public String redirect() {
	      return "redirect:finalPage,finalpage1,finalpage2,finalpage3";
	}
	@RequestMapping(value = "/finalPage", method = RequestMethod.GET)
	   public String finalPage() {
	      return "CreateAccount.html";
	      
	   }
	
	@RequestMapping(value = "/finalPage1", method = RequestMethod.GET)
	   public String finalPage1() {
	      return "Display.html";
	      
	   }
	@RequestMapping(value = "/finalPage2", method = RequestMethod.GET)
	   public String finalPage2() {
	      return "Deposit.html";
	      
	   }
	@RequestMapping(value = "/finalPage3", method = RequestMethod.GET)
	   public String finalPage3() {
	      return "Withdrawl.html";
	      
	   }
	

	
	
}
