package com.mindtree.Utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Utility {
	
	private String url ="jdbc:mysql://localhost:3306/assign2?useSSL=false";
	private String username="root";
	private String pwd="Welcome123";
	
	public Connection getConnection() throws SQLException, ClassNotFoundException {
		Connection con = null;
		System.out.println("coming");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url,username,pwd);
			System.out.println("Class loaded");
		} 
//		catch (ClassNotFoundException e) {
//			System.out.println("Driver class not found");
//		} 
		catch (SQLException e) {
			System.out.println("Driver class not loaded");
			e.printStackTrace();
		}
		return con;

	}
}
